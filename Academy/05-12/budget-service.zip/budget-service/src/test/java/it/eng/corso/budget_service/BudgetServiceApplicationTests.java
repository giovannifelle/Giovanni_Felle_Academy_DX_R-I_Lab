package it.eng.corso.budget_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgetServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
